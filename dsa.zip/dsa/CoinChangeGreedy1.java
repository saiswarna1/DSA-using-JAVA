import java.util.Scanner;

public class CoinChangeGreedy1 {
    public static void main(String[] args) {
        //given infintite supply of following coin denomination 10,5,2,1 rupees
        //given the target ammount N minimum no of coins to reach the target
        //does not provide optimal solution;
        Scanner sc=new Scanner(System.in);
        int coinCount=0;
        //step1 -> intialize the result;
        //step 2-> soring the intances;
        int[] co={10,5,2,1};
        int target=sc.nextInt();
        for(int i=0;i<co.length;i++){
            int rev=target/co[i];
            coinCount=coinCount+rev;
            target=target%co[i];
        }
        System.out.println(coinCount);
    }
}
