import java.util.*;
public class Collections {
    //non homogeneous
    public static void main(String[] args) {
    Collection nums = new ArrayList();
    nums.add(1);
    nums.add("hello");
  //  nums.remove(1);
    System.out.println(nums);

    }
}
