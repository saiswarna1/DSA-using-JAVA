import java.util.Scanner;

public class Airport {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
        int[] wei=new int[n];
        for(int i=0;i<n;i++)
        wei[i]=sc.nextInt();
        System.out.println("enter threshold");
        int t=sc.nextInt();
        int p=0;
        for(int i=0;i<n;i++){
         if(wei[i]>t)
         p=p+2;
         else
         p=p+1;   
        }
        System.out.println(p);
    }
}
