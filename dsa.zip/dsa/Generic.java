public class Generic {
    public static void main(String[] args) {
        Utility ul=new Utility();
        ul.printArray("hello louda");
    }
    public static class Utility {
         <T> void printArray(T a) {
                System.out.println(a); 
        }
}
}