public class Pattern1 {
    public static void main(String[] args) {
        //outer loop -> row
        //inner loop -> column
        int c=1;
        for(int i=0;i<5;i++){ // be the no of rows
   if(i%2==0)
   {
    for(int j=1;j<=5;j++){
        System.out.print(c + " ");
        c++;
    }
    System.out.print("\n");
   }
else{
    c=c-1;
    c=c+5;
    for(int j=0;j<5;j++){
 System.out.print(c + " ");
c=c-1;
    }
    System.out.print("\n");
    c=c+6;
}
        }
        }
    }

