import java.util.Stack;

public class MaxHistogramStack {
    public static void main(String[] args) {
       int[] heights = {2,1,5,6,2,3};
       System.out.println(largestRectangleArea(heights));
    }
    public static int largestRectangleArea(int[] heights) {
        //we need to find the largest rectangle
        Stack<Integer> st=new Stack<>();
        Stack<Integer> st1=new Stack<>();
        int[] prev=new int[heights.length];
        int[] next=new int[heights.length];
        //find the previous smaller bar on the left
        for(int i=0;i<heights.length;i++){
            while(!st.isEmpty() && heights[st.peek()]>=heights[i])
            st.pop();
if(st.isEmpty())
prev[i]=-1;
else
prev[i]=st.peek();
st.push(i);
        }
        //find the next smaller bar on right
        for(int i=heights.length-1;i>=0;i--){
                   while(!st1.isEmpty() && heights[st1.peek()]>=heights[i])
            st1.pop();
if(st1.isEmpty())
next[i]=heights.length;
else
next[i]=st1.peek();
st1.push(i);
        }
        int max=-1;
        for(int i=0;i<heights.length;i++){
            int h=heights[i];
            int l=next[i]-prev[i]-1;
int area=h * l;
max=Math.max(max,area);
        }
        return max;
    }
}
