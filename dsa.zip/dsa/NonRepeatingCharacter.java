import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Scanner;
public class NonRepeatingCharacter {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str = sc.nextLine();
        String ans="";
        String view="-1";
        int n = str.length();
        HashMap<Character,Integer> hm=new HashMap<>();
        ArrayDeque<Character> aq=new ArrayDeque<>();
        for(int i=0;i<n;i++){
            //step1 update frequency and it into queue;
            char ch=str.charAt(i);
            aq.offer(ch);
hm.put(ch,hm.getOrDefault(ch, 0)+1);
//check the frequency of the front of the queue and if 1 add it into the String;
while(!aq.isEmpty()){
char cp=aq.peekFirst();
if(hm.get(cp)==1){
    ans+=cp;
    break;
}
else
aq.pollFirst();
        }
      if(aq.isEmpty())
      {
        ans=ans+view;
      }
    }
    System.out.println(ans);
}
}