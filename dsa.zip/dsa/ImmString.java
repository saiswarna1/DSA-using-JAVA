public class ImmString {
    public static void main(String[] args) {
        String l= new String("hyderabad");
        System.out.println(l);
       String v= l.concat("city");
        System.out.println(l);
        System.out.println(v);
    }
}
