public class Pattern8 {
    public static void main(String[] args) {
       for(int i=1;i<=4;i++){
        if(i==4){
            for(int j=1;j<=4-1;j++)
            System.out.print("*"+" ");
        }
        else{
        for(int j=1;j<=4;j++){
            if(j==1 || j==i)
            System.out.print("*"+" ");
            else
            System.out.print(" "+" ");
 }
System.out.println();
    }
}
//downward putting
for(int i=1;i<=3;i++){
    for(int j=1;j<=4;j++){
        if(j==1 || j+i==5)
System.out.println("*" + " ");
    }
}
}
}
