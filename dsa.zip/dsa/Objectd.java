public class Objectd {
    int num;
    float b;
    Objectd(int num,float b){
        this.num=num;
        this.b=b;
    }
    @Override
    public int hashCode(){
        return 1;
    }
    public static void main(String[] args) {
        // Create a new object
        //Car myCar = new Car();
Objectd ob=new Objectd(10,8.9f);
Objectd ob1=ob;
Objectd ob3=ob;

//hashcode();
//toString();
//equals();
//getClass();
//wait();
if(ob3==ob1)
System.out.println("equals");
if(ob3.equals(ob1))
System.out.println("equals by meth");
System.out.println(ob.getClass().getName());
    }
}
