public class Static1 {
    int rn;
    String name;
    static int our;
    public Static1(int rn,String name){
        this.rn=rn;
        this.name=name;
        Static1.our+=1;
    }
}
