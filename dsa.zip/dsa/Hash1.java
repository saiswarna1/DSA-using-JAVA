import java.util.HashMap;

public class Hash1 {
    public static void main(String[] args) {
        // Create a HashMap to store the counts of elements
        HashMap<Character, Integer> counts = new HashMap<>();

        // Example string
        String str = "abracadabra";

        // Count occurrences of each character
        for (char c : str.toCharArray()) {
            counts.put(c, counts.getOrDefault(c, 0) + 1);
        }

        // Print the counts
        for (char c : counts.keySet()) {
            System.out.println("Character: " + c + ", Count: " + counts.get(c));
        }
    }
}

