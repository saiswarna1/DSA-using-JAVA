public class JumpSearch {
    public static void main(String[] args) {
       // int i=0;
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8};
        int target = 8;
        System.out.println(jum(arr,target));
        System.out.println(exp(arr,target));

}

public static int jum(int[] arr,int target){
    int i=0;
    int step = (int) Math.sqrt(arr.length);
        int start = i;
        while(i<arr.length){
            if(arr[i]==target){
         // System.out.println("Found at index "+i);
          return i;
        }
        else if(target>arr[i]){
            start=i+1;
            i=i+step;
            if(i>=arr.length)
            break;
        }
        else
        {
        break;
        }
    }
    i=i>=arr.length?arr.length:i;
    for(int k=start;k<i;i++){
        if(arr[k]==target){
            return k;
    }
}
return -1;
}
public static int exp(int[] arr,int key){
    if(key == arr[0])
    return 0;
int i = 1;
int start = 0;
while(i < arr.length) {
    if(key == arr[i])
        return i;
    else if(key > arr[i]) {
        start = i + 1;
        i = i * 2;
    } else
        break;
}
for(int idx = start; idx < arr.length && idx < i; idx++)
    if(key == arr[idx])
        return idx;
return -1;

}
}
