//import java.lang.*;
//working in the online compile
public class CustomArrayListGeneric<T>{
    private  int size=0;
    private int capacity=10;
    Object[] data;
    public CustomArrayListGeneric(){
        data = new Object[capacity];
    }
    public void add(T element){
//add if not full if full resize it;
if(size==capacity){
resize();
}
data[size++]=(Object)element;
    }
    public void resize(){
        Object temp[]=new Object[2*capacity];
        for(int i=0;i<capacity;i++){
            temp[i]=data[i];
        }
        data=temp.clone();
    }
    public T remove(){
       T removed=(T)data[size--];
        return removed;
    }
    public T get(int index){
        if(index<0||index>=size){
            throw new IndexOutOfBoundsException();
        }
        return (T)data[index];
    }
    public void set(int index,T element){
        if(index<0||index>=size)
        throw new IndexOutOfBoundsException();
       data[index]=(Object)element; //bigger to smaller no need to add typecast
    }
    public int size(){
        return size;
    }
    public String toString(){
        for(int i=0;i<size;i++){
            System.out.print(data[i]+" ");
        }
        return "";
}
public static void main(String[] args) {
    CustomArrayListGeneric<String> list = new CustomArrayListGeneric<>();
   // list.add(10);
    list.add("hello");
    list.add("world");
    list.add("java");
    System.out.println(list);
}
}
/* 
public class CustomArrayListGeneric<T> {
    private int size = 0;
    private int capacity = 10;
    private Object[] data;

    public CustomArrayListGeneric() {
        data = new Object[capacity];
    }

    public void add(T element) {
        if (size == capacity) {
            resize();
        }
        data[size++] = (Object) element;
    }

    public void resize() {
        Object[] temp = new Object[2 * capacity];
        for (int i = 0; i < capacity; i++) {
            temp[i] = data[i];
        }
        data = temp;
        capacity *= 2;
    }

    public T remove() {
        if (size == 0) {
            throw new IndexOutOfBoundsException("List is empty");
        }
        @SuppressWarnings("unchecked")
        T removed = (T) data[--size];
        data[size] = null; // Avoid memory leak
        return removed;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        @SuppressWarnings("unchecked")
        T element = (T) data[index];
        return element;
    }

    public void set(int index, T element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        data[index] = (Object) element;
    }

    public int size() {
        return size;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i != size - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        CustomArrayListGeneric<String> list = new CustomArrayListGeneric<>();
        list.add("hello");
        list.add("world");
        list.add("java");
        System.out.println(list); // Output: hello world java

        list.set(1, "universe");
        System.out.println(list); // Output: hello universe java

        list.remove();
        System.out.println(list); // Output: hello universe

        System.out.println("Size: " + list.size()); // Output: Size: 2
    }
}
*/




/* 
public class CustomArrayListGeneric<T> {
    private int size = 0;
    private int capacity = 10;
    private Object[] data;

    public CustomArrayListGeneric() {
        data = new Object[capacity];
    }

    public void add(T element) {
        if (size == capacity) {
            resize();
        }
        data[size++] = (Object)element;
    }

    public void resize() {
        Object[] temp = new Object[2 * capacity];
        System.arraycopy(data, 0, temp, 0, capacity);
        data = temp;
        capacity *= 2;
    }

    public T remove() {
        if (size == 0) {
            throw new IndexOutOfBoundsException("List is empty");
        }
        @SuppressWarnings("unchecked")
        T removed = (T) data[--size];
        data[size] = null; // Avoid memory leak
        return removed;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        @SuppressWarnings("unchecked")
        T element = (T) data[index];
        return element;
    }

    public void set(int index, T element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        data[index] = element;
    }

    public int size() {
        return size;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i != size - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        CustomArrayListGeneric<String> list = new CustomArrayListGeneric<>();
        list.add("hello");
        list.add("world");
        list.add("java");
        System.out.println(list); // Output: hello world java

        list.set(1, "universe");
        System.out.println(list); // Output: hello universe java

        list.remove();
        System.out.println(list); // Output: hello universe

        System.out.println("Size: " + list.size()); // Output: Size: 2
    }
}
*/



/* 
public class CustomArrayListGeneric<T> {
    private int size = 0;
    private int capacity = 10;
    private Object[] data;

    public CustomArrayListGeneric() {
        data = new Object[capacity];
    }

    public void add(T element) {
        if (size == capacity) {
            resize();
        }
        data[size++] = element;
    }

    public void resize() {
        Object[] temp = new Object[2 * capacity];
        System.arraycopy(data, 0, temp, 0, capacity);
        data = temp;
        capacity *= 2;
    }

    public T remove() {
        if (size == 0) {
            throw new IndexOutOfBoundsException("List is empty");
        }
        @SuppressWarnings("unchecked")
        T removed = (T) data[--size];
        data[size] = null; // Avoid memory leak
        return removed;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        @SuppressWarnings("unchecked")
        T element = (T) data[index];
        return element;
    }

    public void set(int index, T element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        }
        data[index] = element;
    }

    public int size() {
        return size;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i != size - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        CustomArrayListGeneric<String> list = new CustomArrayListGeneric<>();
        list.add("hello");
        list.add("world");
        list.add("java");
        System.out.println(list); // Output: hello world java

        list.set(1, "universe");
        System.out.println(list); // Output: hello universe java

        list.remove();
        System.out.println(list); // Output: hello universe

        System.out.println("Size: " + list.size()); // Output: Size: 2
    }
}

*/




/* 
public class CustomArrayListGeneric<T> {
    private int size = 0;
    private int capacity = 10;
    private Object[] data;

    public CustomArrayListGeneric() {
        data = new Object[capacity];
    }

    public void add(T element) {
        if (size == capacity) {
            resize();
        }
        data[size++] = element;
    }

    public void resize() {
        capacity *= 2;
        Object[] temp = new Object[capacity];
        System.arraycopy(data, 0, temp, 0, size);
        data = temp;
    }

    public T remove() {
        if (size == 0) {
            throw new IndexOutOfBoundsException("List is empty");
        }
        @SuppressWarnings("unchecked")
        T removed = (T) data[--size];
        data[size] = null; // Avoid memory leak
        return removed;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        @SuppressWarnings("unchecked")
        T element = (T) data[index];
        return element;
    }

    public void set(int index, T element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        data[index] = element;
    }

    public int size() {
        return size;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i != size - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        CustomArrayListGeneric<String> list = new CustomArrayListGeneric<>();
        list.add("hello");
        list.add("world");
        list.add("java");
        System.out.println(list); // Output: hello world java

        list.set(1, "universe");
        System.out.println(list); // Output: hello universe java

        list.remove();
        System.out.println(list); // Output: hello universe

        System.out.println("Size: " + list.size()); // Output: Size: 2
    }
}
*/