public  abstract class AbstractParent {
    int age;
    AbstractParent(int age){
this.age=age;
    }
    static void re(){
        System.out.println("static method in parent");
    }
    void normal(){
        System.out.println("normal method in parent");
    }
    abstract void fun(String a);
    void fun(int a) {
        System.out.println("yes");
    }
}