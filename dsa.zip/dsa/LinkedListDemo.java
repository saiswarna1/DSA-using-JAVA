// File: LinkedListDemo.java
public class LinkedListDemo {
    // Definition for singly-linked list
    public static class ListNode {
        int val;
        ListNode next;

        ListNode() {}

        ListNode(int val) {
            this.val = val;
        }

        ListNode(int val, ListNode next) {
            this.val = val;
            this.next = next;
        }
    }
    // LinkedList class to manage list operations
    public static class LinkedList {
        ListNode head;
        // Method to add a new node at the end of the list
        public void add(int val) {
            if (head == null) {
                head = new ListNode(val);
            } else {
                ListNode current = head;
                while (current.next != null) {
                    current = current.next;
                }
                current.next = new ListNode(val);
            }
        }
        // Method to find the middle element using slow and fast pointers
        public ListNode findMiddleandremove() {
            if (head == null) {
                return null;
            }

            ListNode slow = head;
            ListNode fast = head;
ListNode prev=null;
            while (fast != null && fast.next != null) {
                prev=slow;
                slow = slow.next;
                fast = fast.next;
                fast = fast.next;
            }
if(prev !=null)
{
    prev.next=slow.next;
}
            return slow;
        }
      
        // Method to display the linked list
        public void display() {
            ListNode current = head;
            while (current != null) {
                System.out.print(current.val + " -> ");
                current = current.next;
            }
            System.out.println("null");
        }
        public ListNode findremovekth(int k){
            ListNode t1=head;
            ListNode t2=head;
            ListNode prev=null;

            while(t2!=null){
                if(k>0){
                    t2=t2.next;
                    k--;
                }
                else
                {
                    prev=t1;
                    t1=t1.next;
                    t2=t2.next;
                }
            }
            prev.next=t1.next;
            return t1;
        }
        //1 -> 2->3->4->5;
        //3 pointer appraoch can be used;
        
    }
    // Main method to demonstrate the linked list operations
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
list.add(56);
list.add(34);
list.add(564);
list.add(234);
list.add(235);
        list.display();

        ListNode middle = list.findMiddleandremove();
        if (middle != null) {
            System.out.println("The middle element is: " + middle.val);
        } else {
            System.out.println("The list is empty.");
        }
        list.display();
        ListNode kp=list.findremovekth(2);
        System.out.println(kp.val);
        list.display();
    }
}

