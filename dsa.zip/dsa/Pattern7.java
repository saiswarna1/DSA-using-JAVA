import java.util.*;
public class Pattern7 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s="sending";
        int n=s.length();
        for(int i=1;i<=n;i++){
            String emp="";
//take the string 

//triangle 1
for(int j=1;j<=n-i;j++)
System.out.print(" ");
//2
for(int j=1;j<=i;j++)
System.out.print(s.charAt(j-1));

System.out.println();
    }
}
}