import java.util.Arrays;
import java.util.Scanner;

public class Rat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        int unit=sc.nextInt();
        int[] arr=new int[8];
        Arrays.setAll(arr,(i)-> arr[i]=sc.nextInt());
        int foodreq=n * unit;
        int foodarrived=0;
        int c=0;
        for(int i=0;i<arr.length;i++){
            if(foodarrived<foodreq){
                foodarrived+=arr[i];
                c=c+1;
        }
        else
        break;
    }
    System.out.println("no of houses");
    System.out.println(c);
}
}