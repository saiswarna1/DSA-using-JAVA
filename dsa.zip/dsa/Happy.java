import java.util.Scanner;
public class Happy {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int p=1;
        for(int i=0;i<2;i++){
          int r=n%10;
            p=p * r;
            n=n/10;
        }
        int s=0;
        while(n!=0){
            int k1=n%10;
            s=s+k1;
            n=n/10;
        }
        if(p==s)
        System.err.println("yes");
        else
        System.err.println("no");
    }
}
////////a//a//a//a//a///a//a///
/*what the fuck is going louda]*/