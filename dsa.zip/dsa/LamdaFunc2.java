import java.util.ArrayList;
import java.util.function.Consumer;

public class LamdaFunc2 {
    public static void main(String[] args) {
        // 1. 定义一个函数式接口
        ArrayList<Integer> al=new ArrayList<>();
        al.add(1);
        al.add(2);
        al.add(34);
        al.add(5);
        al.add(6);
        al.add(7);
        Consumer<Integer> meth= (n) -> {System.out.println(n);};
        al.forEach(meth);
    }
}
