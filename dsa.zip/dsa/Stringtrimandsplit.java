import java.util.Scanner;

public class Stringtrimandsplit {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String line=sc.nextLine();
        String[] kp=line.trim().split("");
        //spliiting the white spaces;
        int[] ans=new int[kp.length];
        for(int i=0;i<kp.length;i++){
            ans[i]=Integer.parseInt(kp[i]);
    }
    for(int i=0;i<ans.length;i++){
        System.out.println(ans[i]);
}
}
}
