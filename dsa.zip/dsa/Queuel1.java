public class Queuel1 {
    private int[] arr;
    private int rear;
    private int size;
    private int front;
    
    public static void main(String[] args) {
        Queuel1 q = new Queuel1(3);
        q.add(1);
        q.add(2);
        q.add(3);
        q.remove();
        q.add(4);
        System.out.println(q.peek());
    }
    
    Queuel1(int n) {
        arr = new int[n];
        size = n;
        rear = -1;
        front = -1;
    }
    
    public boolean isEmpty() {
        return (rear == -1 && front == -1);
    }
    
    public boolean isFull() {
        return ((rear + 1) % size == front);
    }
    
    public void add(int n) {
        if (isFull()) {
            System.out.println("Queue is full");
            return;
        }
        if (front == -1) {
            front = 0;
        }
        rear = (rear + 1) % size;
        arr[rear] = n;
    }
    
    public int remove() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }
        int result = arr[front];
        if (rear == front) { // Queue is now empty
            rear = -1;
            front = -1;
        }
            front = (front + 1) % size;  
        return result;
    }
    
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }
        return arr[front];
    }
}
