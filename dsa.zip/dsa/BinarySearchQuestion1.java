import java.util.Scanner;

public class BinarySearchQuestion1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
     int[] arr = {0,1,1,2,2,3,3,3,3,4,4,4,5};
        int target = sc.nextInt();
int l=0;
int h=arr.length-1;
while(l<=h){
    int mid=l+(h-l)/2;
    if(arr[mid]==target || (arr[mid]>target && arr[mid-1]<target)){
        System.out.println(mid);
        break;
}
else if(target< arr[mid])
h = mid - 1;
else
 l = mid + 1;
    }
}
}
