import java.util.Scanner;
public class AngryBirds {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
    static boolean canPlace(int[] nests, int birds, int minDistance) {
        int birdsPlaced = 1;
        int placedAt = nests[0];

        for(int i = 1; i < nests.length; i++) {
            int currentDistance = nests[i] - placedAt;
            if(currentDistance >= minDistance) {
                birdsPlaced++;
                placedAt = nests[i];
                if(birdsPlaced == birds)
                    return true;
            }
        }
        return false;
    }

    static int angryBirds(int[] nests, int birds) {
        int n = nests.length;
        int low = 0, high = nests[n-1] - nests[0];
        int answer = 0;

        while(low <= high) {
            int mid = (low + high) / 2;
            if(canPlace(nests, birds, mid)) {
                answer = mid;
                low = mid + 1;  // Right
            } else
                high = mid - 1; // Left
        }
        return answer;
    }
}
