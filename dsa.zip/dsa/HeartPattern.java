public class HeartPattern {
    public static void main(String[] args) {
        int size = 6; // size of the heart
        for (int i = size / 2; i <= size; i += 2) {
            // print first spaces
            for (int j = 1; j < size - i; j += 2) {
                System.out.print(" ");
            }
            // print first stars
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            // print middle spaces
            for (int j = 1; j <= size - i; j++) {
                System.out.print(" ");
            }
            // print second stars
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        // lower part of the heart
        for (int i = size; i >= 1; i--) {
            // print leading spaces
            for (int j = i; j < size; j++) {
                System.out.print(" ");
            }
            // print stars
            for (int j = 1; j <= (i * 2) - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}

