public class Exception2 {
    public static void main(String[] args) {
        
    }
}
