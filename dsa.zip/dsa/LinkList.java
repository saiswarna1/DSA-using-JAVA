import java.util.Stack;

 class PalinStack {
    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        LinkList list = new LinkList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(2);
        list.add(1);
        list.display();
    }

public static class LinkNd {
    int data;
    LinkNd next;
    LinkNd(int data) {
        this.data = data;
        this.next = null; // Corrected initialization
    }
}
public static class LinkList {
    LinkNd head;

    public void add(int val) {
        if (head == null) {
            head = new LinkNd(val);
        } else {
            LinkNd temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = new LinkNd(val);
        }
    }

    public void display() {
        LinkNd temp = head;
        while (temp != null) {
            System.out.print(temp.data + "->");
            temp = temp.next;
        }
        System.out.println("null");
    }

}
 }

