import java.util.ArrayList;
public class StackFromArrayList {
    public static void main(String[] args) {
        Stack s=new Stack();
        s.push(1);
        s.push(2);
        s.push(3);
        System.err.println(s.peek());
    }
    static class Stack{
        static ArrayList<Integer> li=new ArrayList<>();
        public static boolean isEmpty(){
            return li.size()==0;
        }
        public static void push(int a){
            li.add(a);
        }
        public static void pop(){
int top=li.get(li.size()-1);
li.remove(li.size()-1);
        }
        public static int peek(){
            return li.get(li.size()-1);

    }
}
}
