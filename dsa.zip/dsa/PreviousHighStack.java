import java.util.*;

//import StackFromArrayList.Stack;

public class PreviousHighStack {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[] stocks={100,80,60,70,60,85,100};
        //we need to caluclate the previous high values;
        int[] ans=new int[stocks.length];
        Stack<Integer> st=new Stack<>();
        for(int i=0;i<stocks.length;i++){
            //find the previous high values and add it to the stack;
            //found the previous ;
            while(!st.empty() && stocks[st.peek()]<=stocks[i])
            st.pop(); //pop until you are out;
            if(st.empty())
            ans[i]=-1;
            else{
                ans[i]=stocks[st.peek()]; //this is the way of getting the prvious high element;
            }
            st.push(i);
        }
        for(int i=0;i<ans.length;i++){
            System.out.println(ans[i] + " ");
        }
    }

}
