public class TypeCast2 {
    public static void main(String[] args) {
        long a=1001;
        float b=a;
        System.err.println(b);
    }
}
