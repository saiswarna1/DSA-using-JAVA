import java.util.Scanner;

public class RightShiftExample {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int value = sc.nextInt();
        int p=sc.nextInt();
        int shifted = value >> p;
        
        System.out.println("Original value: " + value);
        System.out.println("Shifted value: " + shifted);
    }
}
