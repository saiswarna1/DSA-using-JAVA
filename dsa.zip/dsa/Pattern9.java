public class Pattern9 {
    public static void main(String[] args) {
        //first up
        for(int i=1;i<=5;i++){
            for(int j=1;j<=5;j++){
                if(i==j)
                System.out.print(i+" ");
                else
                System.out.print("  ");
        }
        for(int j=1;j<=5;j++){
if(i+j==6)
System.out.print(i);
        }
        System.out.println();
    }
}
}
