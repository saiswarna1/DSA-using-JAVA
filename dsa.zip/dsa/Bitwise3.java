import java.util.Scanner;

public class Bitwise3 {
    //even or odd without using arthemetic operation;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int s=sc.nextInt();
        int r = s & 1;
        if(r==0){
            System.out.println("even");
    }
    else
System.out.println("odd");
}
}
