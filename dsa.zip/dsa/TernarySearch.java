public class TernarySearch {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8,9};
        int target = 5;
        int l=0;
        int h=arr.length-1;
        while(l<=h){
            int temp=(h-l)/3;
            int m1=l+temp;
            int m2=h-temp;
            if(arr[m1]==target){
                System.out.println("Element found at index "+m1);
                break;
        }
        //check the left side of m1;
        else if(target<arr[m1])
        {
            h=m1-1;
        }
           else if(arr[m2]==target){
            System.out.println(m2);
            break;
           }
            else if(target<arr[m2]){
                l=m1+1;
                h=m2-1;
            }
            else{
                l=m2+1;
            }
        }
    }
}



