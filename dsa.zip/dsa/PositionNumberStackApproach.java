import java.util.*;
public class PositionNumberStackApproach {
    public static void main(String[] args) {
        Stack<Integer> st=new Stack<>();
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
    }
    int[] ans=new int[n];
    ans[0]=-1;
   // st.push(arr[0]);
    for(int i=n-1;i>=0;i--){
        while(!st.empty() && st.peek()<arr[i])
        st.pop();
        ans[i]=st.empty()?-1:st.peek();
        st.push(arr[i]);
    }
    for(int i=0;i<n;i++){
        System.out.print(ans[i]+" ");
}
}}