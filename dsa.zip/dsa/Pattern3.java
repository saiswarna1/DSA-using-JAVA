public class Pattern3 {
    public static void main(String[] args) {
        int size = 6; // Adjust the size for a larger or smaller heart
        
        // Upper part of the heart
        for (int i = size / 2; i <= size; i += 2) {
            // Print spaces before the first peak
            for (int j = 1; j < size - i; j += 2) {
                System.out.print(" ");
            }

            // Print the first peak
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }

            // Print spaces between the two peaks
            for (int j = 1; j <= size - i; j++) {
                System.out.print(" ");
            }

            // Print the second peak
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }

            System.out.println();
        }

        // Lower part of the heart
        for (int i = size; i >= 1; i--) {
            // Print spaces before the base of the heart
            for (int j = i; j < size; j++) {
                System.out.print(" ");
            }

            // Print the base of the heart
            for (int j = 1; j <= (i * 2) - 1; j++) {
                System.out.print("*");
            }

            System.out.println();
        }
    }
}

