import java.util.*;

public class CandiesGreedy {
    public static void main(String[] args) {
        //shop in candy store;
        //for one candy -> k other candies are free
        //minimum amount to n buy n candies -> more free candies
        //maximum amaount to n candies -> less free candies
        Scanner sc=new Scanner(System.in);
        int l=sc.nextInt();
        System.out.println("enter the k value");
        int k=sc.nextInt();
        int[] prices=new int[l];
        System.out.println("enter the cnadies");
        for(int i=0;i<l;i++){
            prices[i]=sc.nextInt();
        }
        int min=0;
        int max=0;
        Arrays.sort(prices);
        int i=0;
        int j=prices.length-1;
        while(i<=j){
//until false it works
min=min+prices[i];
i++;
j=j-k;
        }
        i=0;
         j=prices.length-1;
         while(i<=j){
            max=max+prices[j];
            j--;
            i=i+k;
         }
System.out.println(min);
System.out.println(max);
    }
}
