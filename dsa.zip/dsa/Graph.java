import java.util.*;
//import java.lang.*;
class GraphDS {
    Map<Integer, ArrayList<Integer>> graph;
    GraphDS() {
        graph = new HashMap<>();
    }
    void addEdge(int source, int destination) {
        graph.putIfAbsent(source, new ArrayList<Integer>());
        graph.putIfAbsent(destination, new ArrayList<Integer>());

        graph.get(source).add(destination);
        graph.get(destination).add(source);
    }
    void print() {
        for(int vertex: graph.keySet()) {
            System.out.println(vertex + ": " + graph.get(vertex));
        }
    }
    void bfs(int start) {
      
        Queue<Integer> queue = new ArrayDeque<>();
        Map<Integer, Boolean> isVisited = new HashMap<>();
        for(int vertex: graph.keySet())
            isVisited.put(vertex, false);

        queue.offer(start);
        isVisited.put(start, true);

        while(!queue.isEmpty()) {
            int tmp = queue.peek();
            for(int nbr: graph.get(tmp)) {
                if(!isVisited.get(nbr)){
                    queue.offer(nbr);
                    isVisited.put(nbr, true);
                }
            }
            System.out.print(queue.poll() + " ");
        }
    }
    void dfsHelper(int current, Map<Integer, Boolean> isVisited) {
        isVisited.put(current, true);
        System.out.print(current + " ");

        for(int nbr: graph.get(current)) {
            if(!isVisited.get(nbr)) {
                dfsHelper(nbr, isVisited);
            }
        }
    }
    void dfs(int start) {
        Map<Integer, Boolean> isVisited = new HashMap<>();
        for(int vertex: graph.keySet())
            isVisited.put(vertex, false);
        dfsHelper(start, isVisited);
    }
    boolean isCycle(){
        Map<Integer, Boolean> isVisited = new HashMap<>();
        //visited but not a parent means it refers to a cycle;
        Object start=(int)isVisited.keySet().toArray()[0];
        int k=(int)start;
        return cyclehelper(k, isVisited, -1);

    }
    boolean cyclehelper(int current , Map<Integer,Boolean> visit,int parent){
visit.put(current,true);
for(int nbr : graph.get(current)){
    if(!visit.get(nbr)){
cyclehelper(nbr, visit,current);
    }
    else if(nbr != parent) //if not parent then we return true;
    return true;
}
return false;
    }
    void findDistances(int start) {
        Queue<Integer> queue = new ArrayDeque<>();
        Map<Integer, Boolean> isVisited = new HashMap<>();
        Map<Integer, Integer> distance = new HashMap<>();
        for(int vertex: graph.keySet()) {
            isVisited.put(vertex, false);
            distance.put(vertex, 0);
        }



        queue.offer(start);
        isVisited.put(start, true);
        distance.put(start, 0);

        while(!queue.isEmpty()) {
            int tmp = queue.peek();
            for(int nbr: graph.get(tmp)) {
                if(!isVisited.get(nbr)){
                    distance.put(nbr, distance.get(tmp)+1);
                    queue.offer(nbr);
                    isVisited.put(nbr, true);
                }
            }
            queue.poll();
        }
        System.out.println(distance);
    }
    void minCost(){
        
    }
}

class Graph {
    public static void main(String[] args) {
        Scanner snr = new Scanner(System.in);
        GraphDS g = new GraphDS();

        int n = snr.nextInt();
        while(n > 0) {
            int src = snr.nextInt();
            int dest = snr.nextInt();

            g.addEdge(src, dest);

            n--;
        }
        g.print();
        g.bfs(1);
      System.out.println(" ");
        g.dfs(1);
        g.isCycle();
    }
}
