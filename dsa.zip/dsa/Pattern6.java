public class Pattern6 {
    public static void main(String[] args) {
        int n = 10;
        for (int i = 1; i <= 10; i++) {
            //triangle 1
            for(int j=1;j<=i;j++){
                System.out.print("*" + " ");
            }
            //triangle 2
            for(int j=i;j<=n;j++)
            System.err.print(" "+" ");
            //3
            for(int j=1;j<=i;j++)
            System.out.print(" "+" ");
            //4
            for(int j=i;j<=n;j++)
            System.err.print(" "+" ");
            System.out.println();
    }
    for (int i = 1; i <= 10; i++){
        //1
        for(int j=1;j<=i;j++)
        System.out.print(" "+" ");
        //2
        for(int j=i;j<=n-1;j++)
        System.err.print(" "+" ");
        //3
        for(int j=1;j<=i-1;j++)
        System.out.print(" "+" ");
        //4
        for(int j=i;j<=n;j++){
            System.out.print("*" + " ");
        }
System.out.println();
    }

}
}
