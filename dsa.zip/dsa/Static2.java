public class Static2 {
    public static void main(String[] args) {
        System.err.println(Static1.our);
        Static1 s=new Static1(10, "bhargav");
        System.out.println(Static1.our);
        System.err.println(s.name);
    }
}
