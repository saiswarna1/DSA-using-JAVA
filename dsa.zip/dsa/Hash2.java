import java.util.HashMap;
import java.util.Map;

public class Hash2{
    public static void main(String[] args) {
        // Create a HashMap
        Map<String, Integer> map = new HashMap<>();

        // Using computeIfAbsent to add a new value if key is not present
        map.computeIfAbsent("apple", k -> 0); // Adds "apple" with value 0
        map.computeIfAbsent("banana", k -> 10); // Adds "banana" with value 10

        System.out.println(map);;;;
    }
}




