public class Pattern2 {
   public static void main(String[] args) {
   // int k=3;
    for(int i=0;i<4;i++){
        if(i==0){
        for(int j=0;j<7;j++){
            if(j==3){
                System.out.print("*");
            }
            else
            {
                System.out.print(" ");
            }
        }
        System.out.print("\n");
    }
    else if(i==2){
        //
        //int t=3-i;
      //  int t1=3+i;
        for(int j=0;j<7;j++){
           if(j==0 || j==6)
           System.out.print(" ");
           else
            System.out.print("*");
        }
        System.out.print("\n");
    }
    else
    {
    int p=3-i;
    int p1=3+i;
    for(int j=0;j<7;j++){
        if(j==p || j==p1){
            System.out.print("*");
    }
    else
    {
        System.out.print(" ");
    }
    }
    System.out.print("\n");
    }
   }
}
}
