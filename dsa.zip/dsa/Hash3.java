public class Hash3 {
    public static void main(String[] args) {
        String key = "example";
int hashValue = key.hashCode();
System.out.println("Hash value of the key: " + hashValue);
    }
}
