import java.util.*;
public class Queuep1 {
    public static void main(String[] args) {
        HashMap<Character,Integer> hm=new HashMap<>();
String v1="aabccxb";
Queue<Character> q1=new LinkedList<>();
for(int i=0;i<v1.length();i++)
{
    char p=v1.charAt(i);
    hm.put(p,hm.getOrDefault(p,0)+1);
    //putting is done
    //-1 printed when queue is empty;
    q1.add(p);
    while(  !q1.isEmpty()&& hm.getOrDefault(q1.peek(),0)>1){
        q1.remove();
    }
    if(q1.isEmpty()){
        System.out.println(-1);
    }
    else
{
    System.out.println(q1.peek());
}
}
    }
}