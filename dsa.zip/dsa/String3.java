import java.util.*;
public class String3 {
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
String v=sc.next();
/*
 *
char[] ch=new char[26];
ch[0]='A';
for(int i=1;i<26;i++){
char p=(char)('A'+i);
ch[i]=p;
}
String end="";
for(int i=0;i<v.length();i++){
    char c=v.charAt(i);
int p1=(c-'A');
int p2=26-p1;
char c1=ch[p2];
end=end+c1;
}
System.out.println(end);
*/
String end="";
for(int i=0;i<v.length();i++){
    char p=v.charAt(i);
    int t1=(p-'A');
    int t2=25-t1;
    char v1=(char)('A'+t2);
    end=end+v1;
}
System.out.println(end);
    }
}
