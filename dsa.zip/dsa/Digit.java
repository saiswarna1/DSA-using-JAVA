public class Digit {
    public static int countDigits(int number) {
        if (number <= 0) {
            throw new IllegalArgumentException("Number must be positive");
        }
        return (int) Math.log10(number) + 1;
    }
    public static void main(String[] args) {
        System.out.println(countDigits(12345)); // Output: 5
        System.out.println(countDigits(987654321)); // Output: 9
        System.out.println(countDigits(1)); // Output: 11
        System.err.println(countDigits(2138831911));
        System.out.println(countDigits(020));
        System.err.println(countDigits(023232423));
    }
}
