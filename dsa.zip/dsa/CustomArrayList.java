import java.util.ArrayList;
public class CustomArrayList {
    private int size=0;
    private int capacity=10;
    int[] data;
    public CustomArrayList(){
        data = new int[capacity];
    }
    public void add(int element){
//add if not full if full resize it;
if(size==capacity){
resize();
}
data[size++]=element;
    }
    public void resize(){
        int temp[]=new int[2*capacity];
        for(int i=0;i<capacity;i++){
            temp[i]=data[i];
        }
        data=temp.clone();
    }
    public int remove(){
        int removed=data[size--];
        return removed;
    }
    public int get(int index){
        if(index<0||index>=size){
            throw new IndexOutOfBoundsException();
        }
        return data[index];
    }
    public void set(int index,int element){
        if(index<0||index>=size)
        throw new IndexOutOfBoundsException();
        data[index]=element;
    }
    public int size(){
        return size;
    }
    public String toString(){
        for(int i=0;i<size;i++){
            System.out.print(data[i]+" ");
        }
        return "";
    }
    public static void main(String[] args) {
        CustomArrayList list = new CustomArrayList();
        list.add(10);
        list.add(20);
        list.add(30);
        System.out.println(list); //tostring; ok
        System.out.println(list instanceof CustomArrayList);
        ArrayList ls=new ArrayList<>();
        ls.add(12);
        ls.add("sd)");
        System.out.println(ls);

    }
}
