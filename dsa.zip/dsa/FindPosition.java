import java.util.Scanner;

public class FindPosition {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the num");
        int inp=sc.nextInt();
        int x=0;
        int y=0;
        int d=10;
        for(int i=1;i<=inp;i++){
            int r=i%4;
            if(r==1){
                x=x+d;
                d=d+10;
            }
            if(r==2)
            {
                y=y+d;
                d=d+10;
            }
            if(r==3)
            {
                x=x-d;
                d=d+1;
            }
            if(r==0)
            {
                y=y-d;
                d=d+1;
            }
        }
System.out.println(x + " values" + y);
    }
}