import javax.swing.*;
import java.awt.*;

public class CarAnimationSwing extends JPanel implements Runnable {
    private int x = 0; // Initial x position of the car
    private int y = 100; // Fixed y position of the car
    private Thread animator;

    public CarAnimationSwing() {
        setPreferredSize(new Dimension(800, 200));
        setBackground(Color.white);
        animator = new Thread(this);
        animator.start();
    }

    @Override
    public void run() {
        while (true) {
            x += 5; // Move the car to the right
            if (x > getWidth()) {
                x = -100; // Reset the position when the car moves off-screen
            }
            repaint();
            try {
                Thread.sleep(50); // Delay for the animation
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw the car
        g.setColor(Color.blue);
        g.fillRect(x, y, 100, 50); // Car body
        g.setColor(Color.black);
        g.fillOval(x + 10, y + 40, 20, 20); // Left wheel
        g.fillOval(x + 70, y + 40, 20, 20); // Right wheel
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Car Animation");
        CarAnimationSwing carAnimation = new CarAnimationSwing();
        frame.add(carAnimation);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
