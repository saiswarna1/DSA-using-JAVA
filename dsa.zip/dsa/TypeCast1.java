public class TypeCast1 {
    public static void main(String[] args) {
        //small in big means automatic or widening typecasting
        //big in small means narrowing typecasting
byte b=10;
double a=b;
char ch='a';
int d=ch;
System.out.println(d);
System.err.println(a);
    }
}
