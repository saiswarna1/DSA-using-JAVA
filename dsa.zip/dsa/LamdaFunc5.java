interface Myown{
    int operation(int a,int b);
}
public class LamdaFunc5 {
    public static void main(String[] args) {
        //sd
Myown mpMyown=getMyown('*');
System.out.println(mpMyown.operation(10, 20));
    }
    public static Myown getMyown(char op){
        switch(op){
            case '+':
            return (a,b)->a+b;
            case '-':
            return (a,b)->a-b;
            case '*':
            return (a,b)->a*b;
            default:
            System.err.println("error");
        }
        return null;
    }
}
