//given a list of n sorted integers and an integer k; find the frequency of k in the list;

import java.util.Scanner;

public class BinarySearchQuestion2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int ans=-1;
        int[] arr = {0,1,1,2,2,3,3,3,3,4,4,4,5};
        int l=0;
        int h=arr.length-1;
        int target=sc.nextInt();
       // int mid=l+(h-l)/2;
        //caluclating the upper bound of the elements;
        while(l<=h){
            int mid=l+(h-l)/2;
if(arr[mid]==target){
ans=mid+1;
l=mid+1;
}
else if(arr[mid]<target)
l=mid+1;
else
h=mid-1;
        }
      //  int upper=ans;
System.out.println(ans);
    }
    
}
