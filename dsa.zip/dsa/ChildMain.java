public class ChildMain {
    public static void main(String args[]){
        Child c = new Child();
        c.greet();
     }
}
