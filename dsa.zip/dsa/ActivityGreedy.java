import java.util.*;

public class ActivityGreedy {
    public static void main(String[] args) {
        //the activity which have to be taken;
        //collection -> interface
        //collections-> class
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] start=new int[n];
        int[] finish=new int[n];
        int c=0;


        }
    }
    //
    class Activity implements Comparable<Activity>{
        int start;
        int finish;
        Activity(int start,int finish){
            this.start=start;
            this.finish=finish;
        }
        public int compareTo(Activity other) {
            return this.finish - other.finish;
        }
    }
