import java.util.*;
import java.util.function.IntUnaryOperator;
public class LamdaFunc4 {
    public static void main(String[] args) {
        IntUnaryOperator fact= (n) -> {
            int result = 1;
            for (int i = 1; i <= n; i++) {
                result *= i;
        }
        return result;
    };
    int k=fact.applyAsInt(4);
    System.out.println(k);
}
}
