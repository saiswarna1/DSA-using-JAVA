public class AccessProtected extends AccessModifier{
    int num;
    AccessProtected(int num){
super(num);
    }
    //done
    public static void main(String[] args) {
       AccessProtected ap= new AccessProtected(5);
        int k=ap.num;
        System.err.println(k);
        System.out.println(ap instanceof Object);
    }
}
