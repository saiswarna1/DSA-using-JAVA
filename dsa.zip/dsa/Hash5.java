import java.util.*;

public class Hash5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        HashMap<Integer,Integer> hm=new HashMap<>();
        int[] arr=new int[10];
        for(int i=0;i<10;i++)
        arr[i]=sc.nextInt();
        for(int i=0;i<10;i++)
        {
            hm.put(arr[i],hm.getOrDefault(arr[i],0)+1);
        }
        for(Map.Entry<Integer,Integer> en : hm.entrySet()){
            System.out.println(en.getKey()+" no of times "+en.getValue());
        }
    }
}
