import java.util.*;
//false -> no duplicates;
//true -> duplicates are present in it;
public class DuplicateParenthesesStack {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Stack<Character> st=new Stack<>();
        String ip=sc.nextLine();
       System.out.println(dup(st, ip));
    }
    public static boolean dup(Stack<Character> st,String ip){
int n=ip.length();
for(int i=0;i<ip.length();i++){
    char cp=ip.charAt(i);
    if(cp=='(')
    st.push(cp);
    else if(cp==')'){
        int c=0;
        if(st.empty())
        return true;
        while(!st.empty() && st.peek()!='(')
        {
            st.pop();
            c++;
        }
        if(c<1)
        return true;
        else
        st.pop();
    }
    else
    {
        st.push(cp);
    }
}
return false;
    }
}
