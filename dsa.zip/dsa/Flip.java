import java.util.Scanner;

public class Flip {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k=sc.nextInt();
        int res=n ^ k;
        int c=0;
        while(res!=0){
c++;
res= res & (res-1);
        }
        System.out.println(c);
    }
}
