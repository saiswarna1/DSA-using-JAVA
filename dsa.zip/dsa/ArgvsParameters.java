public class ArgvsParameters  {
   
    public static void main(String[] args) {
        int x = 10;
        final int y = 20;
        
        // Here, x and y are arguments.
        // They are the actual values passed to the method add.
        int result = add(x, y);
        System.out.println("Result: " + result);
    }
    
    // Here, a and b are parameters.
    // They are placeholders for the values that are passed to the method.
    public static int add(int a, int b) {
        return a + b;
    }
}

