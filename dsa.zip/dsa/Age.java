import java.util.*;
public class Age {
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
int[] age =new int[10];
for(int i=0;i<10;i++)
age[i]=0;
for(int i=0;i<10;i++)
{
String line=sc.nextLine();
if(line.isEmpty())
break;
else{
    int k=Integer.parseInt(line);
    age[i]=k;
}
}
int earn=0;
for(int i=0;i<10;i++){
    if(age[i]==0)
    continue;
    if(age[i]<=17)
    earn=earn+200;
   else if(age[i]>17 && age[i]<=40)
    earn=earn+400;
    else
    {
earn=earn+300;
    }
}
System.out.println(earn);
}
}
//maximum 20
