import java.util.Stack;

public class StackReversal {
    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        st.push(1);
        st.push(2);
        st.push(3);
        System.out.println("Original stack: " + st);
        Reverse(st);
        System.out.println("Reversed stack: " + st);
    }

    public static void Reverse(Stack<Integer> st) {
        if (st.empty()) {
            return;
        }
        int top = st.pop();
        Reverse(st);
        insertAtBottom(st, top);
    }

    private static void insertAtBottom(Stack<Integer> st, int data) {
        if (st.empty()) {
            st.push(data);
            return;
        }
        int top = st.pop();
        insertAtBottom(st, data);
        st.push(top);
    }
}

