/* 
import java.util.*;
public class QueueStack2l3 {
    static Stack<Integer> s1=new Stack<>();
    static Stack<Integer> s2=new Stack<>();
    public static void main(String[] args) {
        QueueStack2l3 q=new QueueStack2l3();
        q.add(1);
        q.add(2);
        System.out.println(q.remove());
    }
    public static boolean isEmpty(){
        return s1.isEmpty();
    }
    public static void add(int x){
while(!s1.isEmpty()){
    s2.push(s1.pop());
}
s1.push(x);
while(!s2.isEmpty()){}
int y=s2.pop();
s1.push(y);
    }
    public static int remove(){
        if(isEmpty()){
            return -1;
        }
        int x=s1.pop();
        return x;
    }
    public static int peek(){
        if(isEmpty()){
            return -1;
                }
                return s1.peek();
            }  
                  }
*/
import java.util.*;

public class QueueStack2l3 {
    static Stack<Integer> s1 = new Stack<>();
    static Stack<Integer> s2 = new Stack<>();

    public static void main(String[] args) {
        QueueStack2l3 q = new QueueStack2l3();
        q.add(1);
        q.add(2);
        q.add(3);
        System.out.println(q.remove()); // 1
        System.out.println(q.remove()); // 2
        System.out.println(q.peek());   // 3
    }

    public static boolean isEmpty() {
        return s1.isEmpty();
    }

    public static void add(int x) {
        // Move all elements from s1 to s2
        while (!s1.isEmpty()) {
            s2.push(s1.pop());
        }

        // Push new element to s1
        s1.push(x);

        // Move all elements back from s2 to s1
        while (!s2.isEmpty()) {
            s1.push(s2.pop());
        }
    }

    public static int remove() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }
        return s1.pop();
    }

    public static int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        }
        return s1.peek();
    }
}
