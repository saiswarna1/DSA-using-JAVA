import java.util.*;
class CharArray {
    public static void main(String[] args) {
        //\\\\System.out.println("Try programiz.pro");
        String ar="bcaedfg";
        String ar1="abcdegf";
        char[] ans=ar.toCharArray();
        char[] ans1=ar1.toCharArray();
       System.out.println(ans.toString());
     Arrays.sort(ans);
       Arrays.sort(ans1);
     if(Arrays.equals(ans,ans1))
     System.out.println("yes");
     else
     System.out.println("no");
    }
}