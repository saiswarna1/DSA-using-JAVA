import java.util.Scanner;

public class Bitwise4 {
    public static void main(String[] args) {
        //given 2 integers -.> check whether same sign or opposite;
        Scanner sc=new Scanner(System.in);
        /*  //given 2 integers -.> check whether same sign or opposite;
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        int res= a ^ b;
        if(res>0)
        System.out.println("same");
        else
        System.err.println("no");
        */

        //given 2 integers n,k check whether k bit of n is set or unset set->0;
        /* 
        int n=sc.nextInt();
        int k=sc.nextInt();
        int res=n>>k;
        res=res & 1;
        if(res==0)
        System.out.println("unset");
        else
        System.out.println("set"); 
        */
        
        //unsetting a bit 
        /* 
int n=sc.nextInt();
int k=sc.nextInt();
int mask=~(1<<k);
int res=n&mask;
System.out.println(res);
*/

//clear the right most set bit(we do not know the position);
/* 
int n=sc.nextInt();
int r=n & (n-1);
System.out.println(r);
*/
//counting the no of 1's in number;
int n=sc.nextInt();
int count=0;
while(n>0)
{
    count++;
    n=n&(n-1);
}
System.out.println(count);
    }
}
