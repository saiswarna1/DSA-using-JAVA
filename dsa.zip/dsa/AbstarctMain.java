public class AbstarctMain {
    public static void main(String[] args) {
       // AbstractParent ap=new AbstractParent();
        AbstractChild ab=new AbstractChild(20);
       // ab.display();
       int v=ab.age;
       System.out.println(v);
      //  ap.fun("p");
        ab.fun("hooray");
        AbstractParent.re();
        //prng normal meth
        ab.normal();
    }
}
