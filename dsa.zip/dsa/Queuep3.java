import java.util.*;
public class Queuep3 {
    public static void main(String[] args) {
        Deque<Integer> d=new LinkedList();
d.addFirst(1);
d.addFirst(2);
d.add(4);
d.remove();
System.out.println(d);
    }
}
