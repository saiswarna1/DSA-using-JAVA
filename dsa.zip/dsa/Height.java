public class Height {
    public static void main(String[] args) {
        
    }
    public int maxArea(int[] height) {
        //o(n*2)->approach can be made;
        //easy done in this way;
        //may be it is the only way
        int n=height.length;
        int max=-1;//store the area;
        for(int i=0;i<n-1;i++){
for(int j=i+1;j<n;j++){
    int mi=Math.min(height[i],height[j]);
    int b=j-i;
    int pmax=mi * b;
    max=Math.max(pmax,max);
}
        }
        return max;
    }
}
