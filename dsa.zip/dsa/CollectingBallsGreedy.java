import java.util.Scanner;

public class CollectingBallsGreedy {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int l1=sc.nextInt();
        int l2=sc.nextInt();
        int[] a=new int[l1];
        int[] b=new int[l2];
        
    }
}
