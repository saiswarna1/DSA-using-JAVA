public class Wrapper{
    public static void main(String[] args) {
        Integer a=100;
       // a = 10;
       int b=100;
    boolean ye=a.equals(b);
    System.out.println(ye);
        System.out.println(a);
    }
}
