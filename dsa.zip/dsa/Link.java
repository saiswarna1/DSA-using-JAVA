import java.util.LinkedList;

public class Link {
    public static void main(String[] args) {
        LinkedList<Integer> ls = new LinkedList<>();
        ls.add(1);
        ls.add(2);
        ls.removeLast();
        ls.add(3);
      //  ls.clear();
        // Print the list to verify the element has been added
        System.out.println(ls);
    }
}


