public class StringBuilderDemo {
    public static void main(String[] args) {
        StringBuilder ans=new StringBuilder();
        ans.append("Hello");
        ans.append("World");
        System.out.println(ans);
        String ans1="";
        //first 
        ans1=ans1+'1';
        ans1=ans1+'0';
        System.out.println(ans1);
//+ and and append are the same in adding
//reversing is done bruh didn't saw it
String bb=ans.reverse().toString();
System.out.println(bb);
//done bruh}{}PP{{{{}}}}
    }
}
