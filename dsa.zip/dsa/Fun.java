public class Fun {
    public static void main(String[] args) {
        System.out.println("  _______");
        System.out.println(" //  ||\\ \\");
        System.out.println("//___||_\\ \\___");
        System.out.println("\\-----___--\\  /");
        System.out.println(" \\ --/   \\  --/ ");
        System.out.println("  \\-/     \\-/");
    /*33//#endregion
    #main(\\2ewenum);;;;/* */
}
}
////#endregion
///////#region
