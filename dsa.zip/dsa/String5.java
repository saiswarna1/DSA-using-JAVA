public class String5 {
    public static void main(String[] args) {
        //concat;
        String hello="grprre";
        String world="world";
        String helloWorld=hello.concat(world);
        System.out.println(helloWorld);
        //replace
        //equalsignorecase
        //contains
        //length
        System.out.println(hello.startsWith("he"));
        System.out.println(hello.indexOf('a'));        
        String we=hello.substring(2, 4);
        System.out.println(we);
        System.out.println(hello.substring(2));
        String pt=hello.toUpperCase();
        System.out.println(pt);
        
    }
}
