public class StackfromLinkedList {
        public static void main(String[] args) {
        Stack s = new Stack();
        s.push(1);
        s.push(2);
        s.push(3);
        System.err.println(s.pop()); // Output should be 3, the last pushed item
    }
    static class Stack {
        Node head = null; // Non-static head
        
        public boolean isEmpty() {
            return head == null;
        }
        
        public void push(int data) {
            Node newNode = new Node(data);
            if (isEmpty()) {
                head = newNode;
            } else {
                newNode.next = head;
                head = newNode; // making it as top of the stack
            }
        }
        
        public int pop() {
            if (isEmpty()) {
                return -1;
            }
            int top = head.data;
            // Move the top forward
            head = head.next;
            return top;
        }
    }
    
    static class Node {
        int data;
        Node next;
        Node(int data) {
            this.data = data;
            this.next = null; // Properly initialize next to null
        }
    }
}

