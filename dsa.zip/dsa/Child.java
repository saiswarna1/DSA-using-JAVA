public class Child extends Parent{
  //int a=10
}
