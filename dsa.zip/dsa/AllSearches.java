import java.util.Scanner;

public class AllSearches {

    static int linearSearch(int[] arr, int key) {
        for(int i = 0; i < arr.length; i++) {
            if(key == arr[i])
                return i;
        }
        return -1;
    }

    static int binarySearch(int[] arr, int key) {
        int low = 0, high = arr.length - 1;

        while(low <= high) {
            int mid = (low + high) / 2;
            if(key == arr[mid])
                return mid;
            else if(key < arr[mid])
                high = mid - 1;
            else
                low = mid + 1;
        }
        return -1;
    }

    static int ternarySearch(int[] arr, int key) {
        int low = 0, high = arr.length - 1;

        while(low <= high) {
            int distance = (high - low) / 3;
            int mid_1 = low + distance;
            int mid_2 = high - distance;

            if(key == arr[mid_1])
                return mid_1;
            else if(key < arr[mid_1])
                high = mid_1 - 1;
            else if(key == arr[mid_2])
                return mid_2;
            else if(key < arr[mid_2]) {
                low = mid_1 + 1;
                high = mid_2 - 1;
            } else
                low = mid_2 + 1;
        }
        return -1;
    }

    static int jumpSearch(int[] arr, int key) {
        int i = 0;
        int jump = (int)Math.sqrt(arr.length);

        int start = i;
        while(i < arr.length) {
            if(key == arr[i])
                return i;
            else if(key > arr[i]) {
                start = i+1;
                i = i + jump;
                if(i >= arr.length)
                    break;
            } else
                break;
        }
        i = i >= arr.length ? arr.length : i;
        for(int idx = start; idx < i; idx++)
            if(key == arr[idx])
                return idx;
        return -1;
    }

    static int exponentialSearch(int[] arr, int key) {
        if(key == arr[0])
            return 0;
        int i = 1;
        int start = 0;
        while(i < arr.length) {
            if(key == arr[i])
                return i;
            else if(key > arr[i]) {
                start = i + 1;
                i = i * 2;
            } else
                break;
        }
        for(int idx = start; idx < arr.length && idx < i; idx++)
            if(key == arr[idx])
                return idx;
        return -1;
    }

    public static void main(String[] args) {
        Scanner snr = new Scanner(System.in);
        int n = snr.nextInt();
        int[] arr = new int[n];
        for(int i = 0; i < n; i++)
            arr[i] = snr.nextInt();
        int key = snr.nextInt();

        System.out.println(exponentialSearch(arr, key));
    }
}


/*
1. Linear Search
2. Binary Search
3. Ternary Search
4. Jump Search
5. Exponential Search
6. Interpolation Search
*/