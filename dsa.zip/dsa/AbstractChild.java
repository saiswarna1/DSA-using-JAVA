public class AbstractChild extends AbstractParent{
    AbstractChild(int age){
        super(age);
        //this.age=age;
    }
    @Override
    void fun(String a){
        System.out.println("AbstractChild fun method with String argument"+ " " +a+age);
    }
    //overiding a normal method;
    @Override
    void normal(){
        super.normal();
    }
}
