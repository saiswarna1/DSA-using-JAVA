import java.util.Scanner;

public class Bus {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = 8; // Number of bus stops
        int[] path = {800, 600, 750, 900, 1400, 1200, 1100, 1500};
        String[] bsp = {"a", "b", "c", "d", "e", "f", "g", "h"};

        // Read the source and destination from the user
        String source = sc.next();
        String destination = sc.next();

        int start = -1;
        int end = -1;

        // Find the index of source and destination
        for (int i = 0; i < n; i++) {
            if (source.equals(bsp[i])) {
                start = i;
            }
            if (destination.equals(bsp[i])) {
                end = i;
            }
        }

        // Check if start and end are valid
        if (start == -1 || end == -1) {
            System.out.println("Invalid source or destination");
            return;
        }

        double fare = 0.0;

        if (start <= end) {
            // Calculate fare from start to end
            for (int i = start; i <= end; i++) {
                fare += path[i];
            }
        } else {
            // Calculate fare from start to end with wrap around
            for (int i = start; i < n; i++) {
                fare += path[i];
            }
            for (int i = 0; i <= end; i++) {
                fare += path[i];
            }
        }

        System.out.println(fare);
    }
}
