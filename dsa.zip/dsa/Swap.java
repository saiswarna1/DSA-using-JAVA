import java.util.*;
public class Swap {
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int dig=(int)Math.log10(n)+1;
    int s=0;
    while(dig!=0){
        int r=n%10;
        int k=(int)(r * Math.pow(10,dig));
        s=s+k;
        dig=dig-1;
        n=n/10;
    }
    System.out.println(s/10);
}
}
