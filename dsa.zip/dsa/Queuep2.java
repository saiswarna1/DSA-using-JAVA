import java.util.*;
public class Queuep2 {
    public static void main(String[] args) {
        Queue<Integer> sec=new LinkedList<>();
for(int i=1;i<=10;i++){
    sec.add(i);
}
Queue<Integer> fir=new LinkedList<>();
int si=sec.size();
for(int i=0;i<si/2;i++){
    fir.add(sec.poll());
}
System.out.println(fir);
while(!fir.isEmpty()){
    int y=fir.poll();
    sec.add(y);
    int y2=sec.remove();
    sec.add(y2);
}
System.out.println(sec);
Stack<Integer> st=new Stack<>();
st.push(1);
st.push(2);
System.out.println(st);
    }
}
