import java.util.Scanner;
import java.util.Stack;

public class ValidParen {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s = sc.nextLine();
        System.out.println(isValid(s));
    }

    public static boolean isValid(String s) {
        char[] ans = s.toCharArray();
        Stack<Character> st = new Stack<>();
        for (int i = 0; i < ans.length; i++) {
            if (ans[i] == '(' || ans[i] == '{' || ans[i] == '[') {
                st.push(ans[i]);
            } else if (ans[i] == ')' || ans[i] == '}' || ans[i] == ']') {
                if (st.empty())
                    return false;
                char pe = st.pop();
                if (ans[i] == ')' && pe != '(')
                    return false;
                if (ans[i] == ']' && pe != '[')
                    return false;
                if (ans[i] == '}' && pe != '{')
                    return false;
            }
        }
        return st.empty();
    }
}
