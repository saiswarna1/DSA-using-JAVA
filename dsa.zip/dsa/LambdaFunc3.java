@FunctionalInterface
interface MyFunctionalInterface {
    int myMethod(int a);
}

public class LambdaFunc3 {
    public static void main(String[] args) {
        // Implementing the interface using a lambda expression
        MyFunctionalInterface myFunc = (message) -> {
            System.out.println("Message: " + message);
            return 4;
        };

        // Calling the method
       System.out.println( myFunc.myMethod(20));
    }
}

