import java.util.*;
public class NextGreaterStack {
    public static void main(String[] args) {
        int[] arr={6,8,0,1,3};
        int[] ans=new int[arr.length];
        Stack<Integer> st=new Stack<>();
        for(int i=arr.length-1;i>=0;i--){
//find the next greater element in the right side;
while(!st.empty() && arr[st.peek()]<arr[i])
st.pop();
if(st.empty())
ans[i]=-1;
else{
    ans[i]=arr[st.peek()];
}
st.push(i);
        }
        for(int i=0;i<ans.length;i++){
            System.out.println(ans[i] + " ");
        }
    }
}
