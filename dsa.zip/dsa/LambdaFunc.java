import java.util.ArrayList;

public class LambdaFunc {
    public static void main(String[] args) {
        ArrayList<Integer> n = new ArrayList<>();
        n.add(1);
        n.add(23);
        n.add(32);

        // Correcting the lambda syntax
        n.forEach((l) -> {
            System.out.println(l);
        });
    }
}

