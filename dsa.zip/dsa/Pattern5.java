public class Pattern5 {
    public static void main(String[] args) {
        int n=5;
        for(int i=1;i<=5;i++){
            //triangle 1;
            for(int c=1;c<=i;c++)
            System.out.print("*");
//triangle 2
for(int c=i;c<=n;c++)
System.out.println(" ");
//triangle 3
for(int c=i;c<=n;c++)
System.out.println(" ");
//
for(int c=1;c<=i;c++)
System.out.print("*");
        
        System.out.println();
        }
    }
}
