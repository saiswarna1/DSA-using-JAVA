import java.util.Scanner;

public class Walls {
   public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int interiorwalls= sc.nextInt();
    int exteriorwalls= sc.nextInt();
    double sqin=sc.nextDouble();
    double sqex=sc.nextDouble();
    //18 -> interior 16 -> exterior
if(interiorwalls>0)
sqin=sqin*interiorwalls;
if(exteriorwalls>0)
sqex=sqex*exteriorwalls;
double tot=sqin * 18 + sqex * 16;
System.out.println(tot);
   } 
}
