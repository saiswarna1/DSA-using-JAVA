public class Opps1 {
    static int a=10;
    //System.out.println(a);
    public static void main(String[] args) {
        System.out.println(a);
    }
}
