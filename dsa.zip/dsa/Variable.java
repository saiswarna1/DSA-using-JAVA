public class Variable {
    int x=10;
    double y;
    public static void main(String[] args) {
        Variable v= new Variable();
        System.err.println(v.x);
        System.err.println(v.y);
    }
}
