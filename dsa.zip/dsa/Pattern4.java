import java.util.*;
public class Pattern4 {
    public static void main(String[] args) {
        //outer loop -> no of rows
        //innner loop -> no of columns;
        Scanner sc = new Scanner(System.in);
        int r=sc.nextInt();
        for(int i=1;i<=r;i++){
            //triangle 1
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            //triangle 2 
            for(int j=i;j<=r-1;j++){
                System.out.print("_" + " ");
            }
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
