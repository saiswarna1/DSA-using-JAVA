public class Queuel2 {
    static class Node {
        int data;
        Node next;
        
        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
 
    static Node head = null;
    static Node tail = null;
 
    public static boolean isEmpty() {
        return head == null && tail == null;
    }
 
    public static void add(int dat) {
        Node newNode = new Node(dat);
        if (head == null) { // First node
            head = newNode;
            tail = newNode;
        } else { // Add at the end
            tail.next = newNode;
            tail = newNode;
        }
    }
 
    public static int remove() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1; // Return a default value indicating empty queue
        }
        
        int data = head.data;
        if (head == tail) { // If there is only one element
            head = null;
            tail = null;
        } else {
            head = head.next;
        }
        return data;
    }
 
    public static void main(String[] args) {
        Queuel2 q = new Queuel2();
        q.add(10);
        q.add(20);
        q.add(30);
        
        System.out.println(q.remove()); // 10
        System.out.println(q.remove()); // 20
        System.out.println(q.remove()); // 30
        System.out.println(q.remove()); // Queue is empty, -1
    }
 }
 