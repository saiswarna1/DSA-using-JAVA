public class LinkDemo2 {
    public static class LinkNd{
        public int data;
        public LinkNd next;
        public LinkNd(int data){
            this.data = data;
    }
    public LinkNd(int data,LinkNd next){
        this.data = data;
        this.next = next;
    }
}
public static class LinkList{
LinkNd head;
public void add(int val){
    if(head==null){
        head=new LinkNd(val);
    }
    else{
        LinkNd temp=head;
        while(temp.next != null)
        temp=temp.next;
        temp.next=new LinkNd(val);
    }
}
public void display(){
    LinkNd temp=head;
    while(temp!=null){
        System.out.print(temp.data+"->");
        temp=temp.next;
    }
    System.out.println("null");
}
}
public static void main(String[] args) {
    LinkList list=new LinkList();
    list.add(1);
    list.add(2);
    list.add(3);
    list.add(4);
    list.add(5);
    list.display();
    list.display();
    
}

}

