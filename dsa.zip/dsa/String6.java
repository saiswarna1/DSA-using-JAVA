public class String6 {
    public static void main(String[] args) {
        String s = "Hello";
        String s1 = "HeLLo";
        boolean b=s.equalsIgnoreCase(s1);
        System.err.println(b);
    }
}
