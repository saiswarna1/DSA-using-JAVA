public class Parent {
    public static void greet(){
        System.out.println("Hello from Parent");
    }
}
