import java.util.Scanner;

public class DP {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int n=sc.nextInt();
        int[] buffer=new int[n+1];
        System.out.println("top down approach is");
        System.out.println(dpgetfibo_td(n, buffer));
        System.out.println("the bottum up is");
        System.out.println(dpgetfibo_bu(n));
    }
    //this is the concept of dp top down approach
    static int dpgetfibo_td(int n,int[] buffer){
if(n==0 || n==1)
return n;
if(buffer[n]!=0)
return buffer[n];
buffer[n]=dpgetfibo_td(n-1, buffer) + dpgetfibo_td(n-2, buffer);
return buffer[n];
    }
    static int dpgetfibo_bu(int n){
        int [] buffer=new int[n+1];
        buffer[0]=0;
        buffer[1]=1;
        for(int i=2;i<=n;i++){
            buffer[i]=buffer[i-1]+buffer[i-2];
        }
        return buffer[n];
    }
}

