 interface fun {
 void fun();

    static void greet() {
        System.out.println("Hello");
    }
    private void tld(){
        System.out.println("tld");
    }
}

public class InterfaceStaticMethods implements fun {
    @Override
    public void fun() {
        System.out.println("yes");
    }

    public static void main(String[] args) {
        InterfaceStaticMethods obj = new InterfaceStaticMethods();
        obj.fun(); // Output: yes

        // Call the static method from the interface
        fun.greet(); // Output: Hello
    }
}

