public class Quiz1 {
    public static void main(String[] args) {
        int a=5;
        int b=~a;//2 //-6
        System.out.println("step1 "+ b); 
        b*=-2; //12
        System.out.println("step2 "+ b); //12
        a+=(b-12); //
        System.out.println("step3 "+ a);
        System.out.println(a+b); //17; 
        //~ means-> +1 then change sign;
    }
}
