public class AccessModifier {
    public int num;
    AccessModifier(int num){
        this.num = num;
    }
    //done;
}
