import java.util.Scanner;

public class String1 {
    //compare to;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1="hello how are you";
        System.out.println(s1.compareTo("iell0"));
        char ch=sc.next().charAt(0);
        System.out.println(ch);
    }
}
