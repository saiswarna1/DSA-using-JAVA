import java.util.Scanner;

public class Bitwise2 {
    //givenn a number n increase the value by one without using arthemetic operation;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int mask=~n;
        int result=mask * -1;
        System.out.println(result);
    }
}
