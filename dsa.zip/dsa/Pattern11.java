public class Pattern11 {
    public static void main(String[] args) {
        // Number of lines in the pattern
        int n = 4;

        // Loop to print each line
        for (int i = 1; i <= n; i++) {
            // Print spaces before the star
            for (int j = n - i; j > 0; j--) {
                System.out.print(" ");
            }
            // Print the star
            System.out.println("*");
        }
    }
}

